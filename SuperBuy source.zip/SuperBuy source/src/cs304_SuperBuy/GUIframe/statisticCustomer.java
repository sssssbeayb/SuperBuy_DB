package cs304_SuperBuy.GUIframe;

import javax.swing.*;

/**
 * Created by xingrex on 2017-11-18.
 */
public class statisticCustomer {
    private JTextField textField1;
    private JButton searchingWithNameButton;
    public JPanel customersPanel;
    private JTable table;


}