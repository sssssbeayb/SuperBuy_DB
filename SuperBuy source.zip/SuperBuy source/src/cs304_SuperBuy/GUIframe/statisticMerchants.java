package cs304_SuperBuy.GUIframe;

import javax.swing.*;

/**
 * Created by xingrex on 2017-11-18.
 */
public class statisticMerchants extends JFrame{
    public JPanel MerchantsPanel;
    private JScrollPane JSP;
    private JTable table1;


}
