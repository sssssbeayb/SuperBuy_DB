package cs304_SuperBuy.GUIframe;

public class statisticAuction {
}
