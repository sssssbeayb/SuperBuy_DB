package cs304_SuperBuy.GUIframe;


        import javax.swing.*;
/**
 * Created by xingrex on 2017-11-18.
 */
public class overviewAuction {

    public JPanel panel1;
    private JTextField textFieldAuctionIDbyC;
    private JButton viewAuctionButton;
    private JButton viewAuctionbyCButton;
}
