package cs304_SuperBuy.Model;

public enum OrderStatus {

    IN_PROCESS,
    SHIPPED,
    DELIVERED;

    private OrderStatus() {
    }
}