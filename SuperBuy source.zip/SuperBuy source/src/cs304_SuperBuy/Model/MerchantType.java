package cs304_SuperBuy.Model;


public enum MerchantType {

    FOOD,
    ELECTRONICS,
    CLOTHING,
    BOOKS,
    MUSIC;

    private MerchantType() {
    }
}